﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNetty
{
    interface IConsumerBuffer
    {

    
        void EnsureWritable(int length);

        void WriteVar32(int value);

        void WriteVar64(long value);

       void EncodeZigZag32(int value);
     void  EncodeZigZag64(long value);

      int GetTagFieldNumber(int tag);

    }
}
