﻿using System;
using System.Text;
using DotNetty.Buffers;
using DotNetty.Transport.Channels;
namespace dotNetty
{
    class EchoClientHandler : ChannelHandlerAdapter
    {
        String message = "client message";

        public EchoClientHandler()
        {
        }

        public override void ChannelActive(IChannelHandlerContext context) => context.WriteAndFlushAsync(message);

        public override void ChannelRead(IChannelHandlerContext context, object message)
        {
            Console.WriteLine("read " + message);
        }

        public override void ChannelReadComplete(IChannelHandlerContext context) => context.Flush();

        public override void ExceptionCaught(IChannelHandlerContext context, Exception exception)
        {
            Console.WriteLine("Exception: " + exception);
            context.CloseAsync();
        }
    }
}
