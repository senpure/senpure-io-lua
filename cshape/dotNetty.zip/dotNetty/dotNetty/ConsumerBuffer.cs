﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DotNetty.Buffers;

namespace dotNetty
{


    internal class ConsumerBuffer
    {
        private static Encoding encoding = Encoding.UTF8;

        private IByteBuffer buffer;
        /// <summary>
        /// 解码的时候使用
        /// </summary>
        private int endIndex;

        public IByteBuffer Buffer { get => buffer; set => buffer = value; }
        public int EndIndex { get => endIndex; set => endIndex = value; }

        public void EnsureWritable(int length)
        {
            buffer.EnsureWritable(length);
        }



        public void WriteVar32(int value)
        {
            while (true)
            {
                if ((value & ~0x7F) == 0)
                {
                    buffer.WriteByte(value);
                    return;
                }
                else
                {
                    buffer.WriteByte((value & 0x7F) | 0x80);
                    value >>= 7;
                }
            }
        }


        public void WriteVar64(long value)
        {

            while (value > 127)
            {
                buffer.WriteByte(((int)value & 0x7F) | 0x80);
                value >>= 7;
            }

            buffer.WriteByte((int)value);


        }

        public int EncodeZigZag32(int value)
        {
            return value << 1 ^ value >> 31;
        }

        public long EncodeZigZag64(long value)
        {
            return value << 1 ^ value >> 63;
        }

        public int DecodeZigZag32(int value)
        {
            // return (int)((n >> 1) ^ (0 - (n & 1)));
            uint v = (uint)value;

            return (int)(v >> 1 ^ -(v & 1));

        }

        public long DecodeZigZag64(long value)

        {
            ulong v = (ulong)value;
            return (long)((v >> 1) ^ (0 - (v & 1)));

        }


        int GetTagWriteType(int tag)
        {
            return tag & 7;
        }

        public int GetTagFieldNumber(int tag)
        {

            return tag >> 3;
        }

        public int MakeTag(int fieldIndex, int writeType)
        {
            return fieldIndex << 3 | writeType;
        }

        public void WriteBooleanl(int tag, bool value)
        {

            WriteVar32(tag);
            WriteBoolean(value);

        }

        public void WriteBoolean(bool value)
        {
            buffer.WriteByte(value ? 1 : 0);
        }

        public void WriteVar32(int tag, int value)
        {
            //Constant.WIRETYPE_VARINT
            WriteVar32(tag);
            WriteVar32(value);
        }


        public void WriteVar64(int tag, long value)
        {
            WriteVar32(tag);
            WriteVar64(value);
        }


        public void WriteSInt(int tag, int value)
        {
            WriteVar32(tag);
            WriteVar32(EncodeZigZag32(value));
        }

        public void WriteSInt(int value)
        {
            WriteVar32(EncodeZigZag32(value));
        }


        public void WriteSLong(int tag, long value)
        {
            WriteVar32(tag);
            WriteVar64(EncodeZigZag64(value));
        }

        public void WriteSLong(long value)
        {
            WriteVar64(EncodeZigZag64(value));
        }

        public void WriteSFixed32(int tag, int value)
        {
            WriteVar32(tag);
            buffer.WriteInt(value);
        }

        public void WriteSFixed32(int value)
        {
            buffer.WriteInt(value);
        }


        public void WriteSFixed64(int tag, long value)
        {
            WriteVar32(tag);
            buffer.WriteLong(value);
        }

        public void WriteSFixed64(long value)
        {

            buffer.WriteLong(value);
        }

        public void WriteFloat(int tag, float value)
        {

            WriteVar32(tag);
            buffer.WriteFloat(value);
        }

        public void WriteFloat(float value)
        {
            buffer.WriteFloat(value);
        }

        public void WriteDouble(int tag, double value)
        {
            WriteVar32(tag);
            buffer.WriteDouble(value);
        }

        public void WriteDouble(double value)
        {
            buffer.WriteDouble(value);
        }

        public void WriteString(int tag, String value)
        {
            WriteVar32(tag);
            WriteString(value);
        }

        public void WriteString(String value)
        {
            byte[] bytes = encoding.GetBytes(value);
            WriteVar32(bytes.Length);
            buffer.WriteBytes(bytes);
        }



        public int ReadVar32()
        {
            byte tmp = buffer.ReadByte();
            if (tmp >= 0)
            {
                return tmp;
            }
            int result = tmp & 0x7f;
            if ((tmp = buffer.ReadByte()) >= 0)
            {
                result |= tmp << 7;
            }
            else
            {
                result |= (tmp & 0x7f) << 7;
                if ((tmp = buffer.ReadByte()) >= 0)
                {
                    result |= tmp << 14;
                }
                else
                {
                    result |= (tmp & 0x7f) << 14;
                    if ((tmp = buffer.ReadByte()) >= 0)
                    {
                        result |= tmp << 21;
                    }
                    else
                    {
                        result |= (tmp & 0x7f) << 21;
                        result |= (tmp = buffer.ReadByte()) << 28;
                        if (tmp < 0)
                        {
                            // Discard upper 32 bits.
                            for (int i = 0; i < 5; i++)
                            {
                                if (buffer.ReadByte() >= 0)
                                {
                                    return result;
                                }
                            }
                        }
                    }
                }
            }
            return result;
        }

        public long ReadVar64()
        {
            int shift = 0;
            long result = 0;
            while (shift < 64)
            {
                byte b = buffer.ReadByte();
                result |= (long)(b & 0x7F) << shift;
                if ((b & 0x80) == 0)
                {
                    return result;
                }
                shift += 7;
            }
            return result;
        }

        public String ReadString()
        {
            byte[] bytes = new byte[ReadVar32()];
            buffer.ReadBytes(bytes);

            return encoding.GetString(bytes);
        }



        public bool ReadBoolean()
        {
            return buffer.ReadBoolean();
        }

        public int ReadSInt()
        {

            return DecodeZigZag32(ReadVar32());
        }

        public long ReadSLong()
        {

            return DecodeZigZag64(ReadVar64());
        }

        public int ReadSFixed32()
        {

            return buffer.ReadInt();
        }

        public long ReadSFixed64()
        {

            return buffer.ReadLong();
        }

        public float ReadFloat()
        {

            return buffer.ReadFloat();
        }

        public double ReadDouble()
        {

            return buffer.ReadDouble();
        }



        public int ReadTag(int endIndex)
        {
            if (buffer.ReaderIndex == endIndex)
            {
                return 0;
            }
            return ReadVar32();
        }

        public void Skip(int tag)
        {
            switch (GetTagWriteType(tag))
            {
                case 0:
                    ReadVar64();
                    break;
                case 1:
                    buffer.SkipBytes(4);
                    break;
                case 2:
                    buffer.SkipBytes(8);
                    break;
                case 3:
                    buffer.SkipBytes(ReadVar32());
                    break;
            }
        }

        public int computeStringSize(int tagVar32Size, String value)
        {
            return tagVar32Size + computeStringSizeNoTag(value);
        }

        public int computeStringSizeNoTag(String value)
        {

            byte[] bytes = encoding.GetBytes(value);
            return computeVar32Size(bytes.Length) + bytes.Length;

        }



        public int computeBooleanSize(int tagVar32Size, bool value)
        {
            return tagVar32Size + computeBooleanSizeNoTag(value);
        }

        public int computeBooleanSizeNoTag(bool value)
        {
            return 1;
        }

        public int computeDoubleSize(int tagVar32Size, double value)
        {
            return tagVar32Size + computeDoubleSizeNoTag(value);
        }

        public int computeDoubleSizeNoTag(double value)
        {
            return 8;
        }

        public int computeFloatSize(int tagVar32Size, float value)
        {
            return tagVar32Size + computeFloatSizeNoTag(value);
        }

        public int computeFloatSizeNoTag(float value)
        {
            return 4;
        }

        public int computeSFixed32Size(int tagVar32Size, int value)
        {
            return tagVar32Size + computeSFixed32SizeNoTag(value);
        }

        public int computeSFixed32SizeNoTag(int value)
        {
            return 4;
        }

        public int computeSFixed64Size(int tagVar32Size, long value)
        {
            return tagVar32Size + computeSFixed64SizeNoTag(value);
        }

        public int computeSFixed64SizeNoTag(long value)
        {
            return 8;
        }

        public int computeSIntSize(int tagVar32Size, int value)
        {
            return tagVar32Size + computeSIntSizeNoTag(value);
        }

        public int computeSIntSizeNoTag(int value)
        {
            return computeVar32Size(EncodeZigZag32(value));
        }

        public int computeSLongSize(int tagVar32Size, long value)
        {
            return tagVar32Size + computeSLongSizeNoTag(value);
        }

        public int computeSLongSizeNoTag(long value)
        {
            return computeVar64Size(EncodeZigZag64(value));
        }


        public int computeVar32Size(int tagVar32Size, int value)
        {
            return tagVar32Size + computeVar32SizeNoTag(value);

        }

        public int computeVar32SizeNoTag(int value)
        {
            return value >= 0 ? computeVar32Size(value) : 5;
        }

        public int computeVar64Size(int tagVar32Size, long value)
        {
            return tagVar32Size + computeVar64SizeNoTag(value);

        }

        public int computeVar32Size(int value)
        {
            if ((value & -128) == 0)
            {
                return 1;
            }
            else if ((value & -16384) == 0)
            {
                return 2;
            }
            else if ((value & -2097152) == 0)
            {
                return 3;
            }
            else
            {
                return (value & -268435456) == 0 ? 4 : 5;
            }
        }

        public int computeVar64SizeNoTag(long value)
        {
            return value >= 0 ? computeVar64Size(value) : 10;
        }

        public int computeVar64Size(long value)
        {
            if ((value & -128L) == 0L)
            {
                return 1;
            }
            else if ((value & -16384L) == 0L)
            {
                return 2;
            }
            else if ((value & -2097152L) == 0L)
            {
                return 3;
            }
            else if ((value & -268435456L) == 0L)
            {
                return 4;
            }
            else if ((value & -34359738368L) == 0L)
            {
                return 5;
            }
            else if ((value & -4398046511104L) == 0L)
            {
                return 6;
            }
            else if ((value & -562949953421312L) == 0L)
            {
                return 7;
            }
            else if ((value & -72057594037927936L) == 0L)
            {
                return 8;
            }
            else
            {
                return (value & -9223372036854775808L) == 0L ? 9 : 10;
            }
        }
    }
}
