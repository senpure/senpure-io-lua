﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNetty
{
    class Student
    {

        public static void  a()
        {
            Console.WriteLine("a");
        }
        public void b(int value,long value2)
        {
            Console.WriteLine("v1"+value+"  v2"+value2);
        }

        public void b(int value)
        {
            Console.WriteLine("b" + value );
        }

        public void MethodA() {

            Console.WriteLine("methodA");
        }
    }
}
