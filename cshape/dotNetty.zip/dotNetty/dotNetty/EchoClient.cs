﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using DotNetty.Codecs;
using DotNetty.Handlers.Logging;
using DotNetty.Transport.Bootstrapping;
using DotNetty.Transport.Channels;
using DotNetty.Transport.Channels.Sockets;


namespace dotNetty
{
    class EchoClient
    {
       public static async Task RunClientAsync()
        {
           
            var group = new MultithreadEventLoopGroup();

       
            string targetHost = "127.0.0.1";
            int port = 2222;
  
            try
            {
                var bootstrap = new Bootstrap();
                bootstrap
                    .Group(group)
                    .Channel<TcpSocketChannel>()
                    .Option(ChannelOption.TcpNodelay, true)
                    .Handler(new ActionChannelInitializer<ISocketChannel>(channel =>
                    {
                        IChannelPipeline pipeline = channel.Pipeline;


                        // pipeline.AddLast(new StringDecoder(Encoding.UTF8));

                        // pipeline.AddLast(new StringEncoder(Encoding.UTF8));
                        pipeline.AddLast(new ConsumerDecoder());
                        pipeline.AddLast(new ConsumerEncoder());
                        pipeline.AddLast(new LoggingHandler());
                        //  pipeline.AddLast("echo", new EchoClientHandler());
                        pipeline.AddLast(new ConsumerHandler());
                    }));

                IChannel clientChannel = await bootstrap.ConnectAsync(new IPEndPoint(IPAddress.Parse(targetHost), port));

                Console.ReadLine();

             //   await clientChannel.CloseAsync();
               // Console.WriteLine("==========================");
            }
            finally
            {
                await group.ShutdownGracefullyAsync(TimeSpan.FromMilliseconds(100), TimeSpan.FromSeconds(1));
            }
        }

   
    }
}
