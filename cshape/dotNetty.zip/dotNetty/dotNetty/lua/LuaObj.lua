

LuaObj = {}
function debug()
end
function LuaObj:sayHello()
    print("lua:hello world ...")
end

function LuaObj:saySomeThing(_str,v)
    print("lua: arg1:".._str.." arg2:"..v)
end

function hello(v)
 print("lua:hello ���")
  v:b(2,5);
    v:b(10);
end

function LuaObj:chello(c)
  c:sayHello();
end
