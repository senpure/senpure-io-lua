logger = {}
logger.trace = function(value)
    print(value)
end
logger.debug = function(value)
    print(value)
end

logger.info = function(value)
    print(value)
end


