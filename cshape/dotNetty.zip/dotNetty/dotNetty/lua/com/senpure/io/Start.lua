ConsumerStart = {}

function ConsumerStart:start()
   local msg = MSG.CShapeTestMessage:new();
    msg.value32=-10;
    msg.value64=-1000;

ConsumerManager:sendMessage(msg)
 msg = MSG.CShapeTestMessage:new();
    msg.value32=-100;
    msg.value64=1000000;
	ConsumerManager:sendMessage(msg)


	 msg = MSG.CShapeTestMessage:new();
    msg.value32=3;
    msg.value64=3;
	ConsumerManager:sendMessage(msg)
end
