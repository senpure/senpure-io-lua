﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DotNetty.Buffers;
using DotNetty.Codecs;
using DotNetty.Transport.Channels;


namespace dotNetty
{
    class ConsumerEncoder : MessageToByteEncoder<ConsumerFrame>
    {
        protected override void Encode(IChannelHandlerContext context, ConsumerFrame message, IByteBuffer output)
        {

            ConsumerBuffer buffer = new ConsumerBuffer();
            buffer.Buffer = output;

            ConsumerContext.luaMessageEncodeFun.Call(null,buffer,message.Message);
        }
    }
}
